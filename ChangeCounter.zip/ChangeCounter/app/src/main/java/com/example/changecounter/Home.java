//my package and imports
package com.example.changecounter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class Home extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        //this Handler will allow me to schedule messages and runnable(s) to be executed at some point in the future
        final Handler handler = new Handler();
        //the postDelay method causes the Runnable r to be added to the message queue, to be run after the specified amount of time elapses.
        handler.postDelayed(() -> { //my Runnable
            Intent nextActivity = new Intent(Home.this, Inputs.class);
            Home.this.startActivity(nextActivity);
            Home.this.finish();
        }, 1500);
    }
}