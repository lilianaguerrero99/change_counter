// my package and imports
package com.example.changecounter;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.content.SharedPreferences;
import android.widget.Button;

import java.text.DecimalFormat;

public class Information extends AppCompatActivity {
    public static final String USER_DATA = "user_data";
    //declaring global variables
    Intent intent;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information);

        //initializing variables
        intent = new Intent(Information.this, Inputs.class);
        DecimalFormat formatter = new DecimalFormat("0.00");
        Button reset = findViewById(R.id.reset_button);
        Bundle extras = getIntent().getExtras();
        TextView p_count = findViewById(R.id.penny_count);
        TextView p_input = findViewById(R.id.penny_input);
        TextView p_total = findViewById(R.id.penny_total);
        TextView p_sleeve = findViewById(R.id.penny_sleeve);
        TextView n_count = findViewById(R.id.nickel_count);
        TextView n_input = findViewById(R.id.nickel_input);
        TextView n_total = findViewById(R.id.nickel_total);
        TextView n_sleeve = findViewById(R.id.nickel_sleeve);
        TextView d_count = findViewById(R.id.dime_count);
        TextView d_input = findViewById(R.id.dime_input);
        TextView d_total = findViewById(R.id.dime_total);
        TextView d_sleeve = findViewById(R.id.dime_sleeve);
        TextView q_count = findViewById(R.id.quarter_count);
        TextView q_input = findViewById(R.id.quarter_input);
        TextView q_total = findViewById(R.id.quarter_total);
        TextView q_sleeve = findViewById(R.id.quarter_sleeve);
        TextView total = findViewById(R.id.total);
        //if the bundle object is not empty, then the variables will be set, else they will remain empty text fields
        if (extras != null) {
            p_count.setText("" + extras.getInt("p_count"));
            p_input.setText("" + formatter.format(extras.getDouble("p_input")));
            p_total.setText("" + formatter.format(extras.getDouble("p_total")));
            p_sleeve.setText("" + extras.getInt("p_sleeve"));

            n_count.setText("" + extras.getInt("n_count"));
            n_input.setText("" + formatter.format(extras.getDouble("n_input")));
            n_total.setText("" + formatter.format(extras.getDouble("n_total")));
            n_sleeve.setText("" + extras.getInt("n_sleeve"));

            d_count.setText("" + extras.getInt("d_count"));
            d_input.setText("" + formatter.format(extras.getDouble("d_input")));
            d_total.setText("" + formatter.format(extras.getDouble("d_total")));
            d_sleeve.setText("" + extras.getInt("d_sleeve"));

            q_count.setText("" + extras.getInt("q_count"));
            q_input.setText("" + formatter.format(extras.getDouble("q_input")));
            q_total.setText("" + formatter.format(extras.getDouble("q_total")));
            q_sleeve.setText("" + extras.getInt("q_sleeve"));

            total.setText("" + formatter.format(extras.getDouble("total")));
        }

        //the reset will clear the data saved in shared preferences and commit the change
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences all_coin_totals = getSharedPreferences(USER_DATA, MODE_PRIVATE);
                SharedPreferences.Editor coin_editor = all_coin_totals.edit();
                coin_editor.clear();
                coin_editor.commit();
                startActivity(intent);
            }
        });
    }
}