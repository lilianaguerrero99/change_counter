/*This class holds the bulk of the code and I plan on making updates later this year.
    Right now it is where I want it and I'm happy with what I have so far.
 */

//my package and imports
package com.example.changecounter;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Inputs extends AppCompatActivity {
    public static final String USER_DATA = "user_data";
    //declaring global variables
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inputs);

        //initializing variables
        final int P_MAX_VAL = 100, N_MAX_VAL = 20, D_MAX_VAL = 10, Q_MAX_VAL = 4;
        final double P_MULTIPLIER = 0.01, N_MULTIPLIER = 0.05, D_MULTIPLIER = 0.10, Q_MULTIPLIER = 0.25;
        final int PENNY_SLEEVE = 50, DIME_SLEEVE = 50, NICKLE_SLEEVE = 40, QUARTER_SLEEVE = 40;
        Button calculate = findViewById(R.id.calculate_button);
        EditText pennies = findViewById(R.id.p);
        EditText nickles = findViewById(R.id.n);
        EditText dimes = findViewById(R.id.d);
        EditText quarters = findViewById(R.id.q);
        double defaultValue = 0.0;
        intent = new Intent(Inputs.this, Information.class);

        calculate.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("DefaultLocale")
            @Override
            public void onClick(View v) {

                double penny = change(pennies.getText().toString(), P_MAX_VAL, P_MULTIPLIER, "p_total", "p_input");
                double nickle = change(nickles.getText().toString(), N_MAX_VAL, N_MULTIPLIER, "n_total", "n_input");
                double dime = change(dimes.getText().toString(), D_MAX_VAL, D_MULTIPLIER, "d_total", "d_input");
                double quarter = change(quarters.getText().toString(), Q_MAX_VAL, Q_MULTIPLIER, "q_total", "q_input");

                int p_sleeve = sleeve(intent.getDoubleExtra("p_total", defaultValue), P_MULTIPLIER, PENNY_SLEEVE, "p_sleeve", "p_count");
                int n_sleeve = sleeve(intent.getDoubleExtra("n_total", defaultValue), N_MULTIPLIER, NICKLE_SLEEVE, "n_sleeve", "n_count");
                int d_sleeve = sleeve(intent.getDoubleExtra("d_total", defaultValue), D_MULTIPLIER, DIME_SLEEVE, "d_sleeve", "d_count");
                int q_sleeve = sleeve(intent.getDoubleExtra("q_total", defaultValue), Q_MULTIPLIER, QUARTER_SLEEVE, "q_sleeve", "q_count");

                intent.putExtra("total", total(penny, nickle, dime, quarter));
                //clearing the values of the text field so when the user goes back the text fields are empty
                pennies.getText().clear();
                nickles.getText().clear();
                dimes.getText().clear();
                quarters.getText().clear();
                startActivity(intent);
            }
        });
    }

    //this method counts the change the user has entered and adds it the current total for each coin
    public double change(String string_input, int maxValue, double multiplier, String coin_total, String current) {
        //count represents the dollar amount of the user's input
        double count = 0;
        int input = 0;
        //checking the input before parsing since you cannot parse an empty string
        //if the string is not empty then parse, else input is already set to 0 and will not go through the while loop
        if (string_input.length() != 0) {
            input = Integer.parseInt(string_input);
        }
        //if the input is great than 0, then it will count of how the user has entered
        while (input != 0) {
            //maxValue is how many of that coin can go into a dollar
            /*ex: user inputs 110 pennies and the max values is 100
                110 is greater than 100 is take away 100, add a dollar to count, and continue if input is still greater than 0
             */
            if (input >= maxValue) {
                //here when it says count++ = $1.00
                count++;
                //take away the $1.00 and count the remaining change if any
                input = input - maxValue;
            } else {
                //if the input is less than the max value we just multiply the input by the multiplier put into decimal form
                double temp = input * multiplier;
                //here count = $1.00 + $0.10 = $1.10
                //if the user just entered 10 pennies it would be count == 0 + $0.10 = $0.10
                count = count + temp;
                //input gets sets to 0 because all the change/leftover change has been counted
                input = 0;
            }
        }
        intent.putExtra(current, count);

        //the shared preference all_coin_totals will save the data of the total for each coin even when the app closes
        SharedPreferences all_coin_totals = getSharedPreferences(USER_DATA, MODE_PRIVATE);
        SharedPreferences.Editor coin_editor = all_coin_totals.edit();
        float default_val = 0.0f;
        double storage = all_coin_totals.getFloat(coin_total, default_val);
        //if there is no total yet, then set the total to the user's current input
        if (storage == 0.0) {
            intent.putExtra(coin_total, count);
            coin_editor.putFloat(coin_total, (float) count);
            coin_editor.commit();
            return count;
        }
        //else, we take the total and add the user's current input to it to get the new total
        else {
            double new_coin_total = storage + count;
            intent.putExtra(coin_total, new_coin_total);
            coin_editor.putFloat(coin_total, (float) new_coin_total);
            coin_editor.commit();
            return (new_coin_total);
        }
    }

    //this method will get the total of all the coins and add them together to get a grand total of how much the user has
    public double total(double p, double n, double d, double q) {
        return (p + n + d + q);
    }

    //this method will tell the user how many sleeves they will need for each coin
    public int sleeve(double input, double multiplier, int sleeve_amount, String sleeves, String amount) {
        int count = 0;
        /*ex: input is $1.10 in pennies and the multiplier is 0.01
                temp = (1.10 /0.01) rounded just in case = 110
         */
        int temp = (int) Math.round(input / multiplier);
        intent.putExtra(amount, temp);

        //while temp is not 0, this loop will determine how many sleeves you need for that give coin amount
        while (temp != 0) {
            //if temp is greater than the sleeve amount then count++
            if (temp >= sleeve_amount) {
                count++;
                temp = temp - sleeve_amount;
            }
            //else break because you don't need any / anymore sleeves
            else {
                break;
            }
        }
        intent.putExtra(sleeves, count);
        return count;
    }
}